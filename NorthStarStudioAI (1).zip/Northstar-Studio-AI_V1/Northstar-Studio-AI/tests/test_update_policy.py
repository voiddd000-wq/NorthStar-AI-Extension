import importlib.util
import os
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("update_policy", ROOT / "update.py")
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class UpdatePolicyTests(unittest.TestCase):
    def test_update_checks_disabled_by_default(self):
        os.environ.pop("VS_ENABLE_AUTO_UPDATES", None)
        os.environ.pop("VS_ALLOW_EXTERNAL_UPDATES", None)
        self.assertFalse(MODULE.update_checks_enabled())

    def test_update_checks_enabled_when_opted_in(self):
        os.environ["VS_ENABLE_AUTO_UPDATES"] = "1"
        self.assertTrue(MODULE.update_checks_enabled())


if __name__ == "__main__":
    unittest.main()
