# Northstar Studio AI — V1

Independent V1 fork built for secure local Roblox Studio development with AI.

![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey)
![License](https://img.shields.io/badge/license-GPL--3.0-blue)
![Version](https://img.shields.io/badge/version-1.0.0-blue)

Northstar Studio AI is a local browser-extension and bridge workflow that connects supported AI chat sites to Roblox Studio through the Studio MCP server. It lets a model inspect your place, read and edit scripts, run Luau, and coordinate iterative development without needing Roblox cookies or browser credential access.

This project is an independently modified V1 version based on the earlier open-source codebase, and it keeps the original GPL-3.0 attribution intact while shipping a cleaner, more security-conscious identity.

## What it does

- Connects a supported AI chat to a local bridge on localhost
- Talks to Roblox Studio through the MCP connection already exposed by Studio
- Inspects the game tree, scripts, and place state before edits
- Reads and edits scripts, ModuleScripts, LocalScripts, and models
- Runs Luau snippets and inspects results in context
- Keeps the local bridge restricted to loopback communication
- Preserves compatibility with the existing Studio and MCP setup unless a security or technical fix is required

## Architecture

```
AI chat site -> browser extension -> local Northstar bridge -> Roblox Studio MCP -> Roblox Studio
```

The bridge runs locally on loopback, accepts only the approved local extension connection, and never accesses Roblox cookies, browser cookies, or any credential material.

## Setup

### 1. Install the extension

- Open Chrome, Edge, Brave, or another Chromium-based browser
- Go to `chrome://extensions`
- Enable Developer mode
- Click Load unpacked
- Select the `northstar-extension` folder from the extracted project

### 2. Open Roblox Studio

- Open a place in Roblox Studio
- Open Assistant AI in the top bar
- Open the assistant menu and choose Manage MCP Servers
- Enable Studio as MCP server

### 3. Launch the bridge

- On Windows: run `start.bat`
- On macOS/Linux: use the platform-specific launcher in the project root
- Keep the bridge on localhost only; do not expose it to the LAN or Internet unless specifically approved

### 4. Start a session

Open a supported AI site and begin a chat. The Northstar panel appears in the page and lets you connect to the local bridge and begin a Roblox Studio workflow.

## Supported AI providers

The project keeps the existing provider compatibility provided by the underlying extension stack, while the product identity and runtime policy are now branded as Northstar Studio AI — V1.

## Security model

- Local-only bridge communication on loopback
- No browser cookie access
- No Roblox cookie or `.ROBLOSECURITY` access
- No credential harvesting or secret storage in project memory
- No remote telemetry or hidden network calls by default
- Update checks are off unless the user explicitly opts in

## Configuration

- Bridge port can be set with `VS_BRIDGE_PORT`
- Optional bridge token support remains available through `VS_BRIDGE_TOKEN`
- External update checks require explicit enablement via the environment variables: `VS_ENABLE_AUTO_UPDATES` or `VS_ALLOW_EXTERNAL_UPDATES`

## Development notes

This V1 retains the original project’s functional architecture and GPL-3.0 licensing while moving the product to a cleaner identity and a safer operational model.

## Attribution and licensing

This project remains under GPL-3.0-or-later and preserves the original open-source attribution requirements. The branding and source identity have been transformed into an independent V1 implementation, but the license and required notices remain intact.

## Troubleshooting

- If the bridge is not connecting, confirm Roblox Studio has MCP enabled
- If the status is offline, confirm the bridge is running locally on the same machine
- If a provider fails, verify that the AI site is one of the supported sites and that the browser extension is loaded
- If a command fails, inspect the bridge logs and Studio MCP state before retrying

## Version

Version: 1.0.0

Project name: Northstar Studio AI — V1
